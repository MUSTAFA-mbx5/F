// Style: مائدة الرافدين — حداثة دافئة، أخضر السدر #2F6B4F، عاجي، طين نحاسي؛ mobile-first RTL.
import { useRef, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, ChefHat, ImagePlus, KeyRound, MapPin, Minus, Pencil, Plus, ShoppingBag, Trash2, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { MapView } from "@/components/Map";

const ASSETS = {
  hero: "/manus-storage/food-burger-hero_833070f7.jpg",
  double: "/manus-storage/food-burger-double_b58b4680.jpg",
  chicken: "/manus-storage/food-burger-chicken_7189506a.jpg",
  crispy: "/manus-storage/food-burger-crispy_167c7036.jpg",
  logo: "/manus-storage/food-burger-logo_94f56147.png",
};

type Dish = { id:number; name:string; description:string; price:number; category:string; image:string; available:boolean };
const seedDishes: Dish[] = [
  { id:1, name:"بركر", description:"بركر لحم مشوي مع خس وصوص فود بركر داخل خبز بالسمسم.", price:1000, category:"البركر", image:ASSETS.double, available:true },
  { id:2, name:"بركر جبن", description:"بركر لحم مع شريحة جبن ذائبة وصوص خاص.", price:1500, category:"البركر", image:ASSETS.double, available:true },
  { id:3, name:"بركر دبل", description:"قطعتان لحم مشوي مع جبن وخضار طازجة.", price:3000, category:"البركر", image:ASSETS.hero, available:true },
  { id:4, name:"صاج دجاج - لحم", description:"صاج ساخن بحشوة الدجاج أو اللحم مع صلصة البيت.", price:3000, category:"الصاج", image:ASSETS.chicken, available:true },
  { id:5, name:"صاج توستر", description:"توستر مقرمش بحشوة فود بركر وصوص غني.", price:3000, category:"الصاج", image:ASSETS.crispy, available:true },
  { id:6, name:"صاج إيطالي", description:"صاج بنكهة إيطالية مع جبن وخضار وصوص خاص.", price:6000, category:"الصاج", image:ASSETS.chicken, available:true },
  { id:7, name:"صاج دجاج", description:"دجاج متبل وخضار طازجة داخل صاج ساخن.", price:5000, category:"الصاج", image:ASSETS.chicken, available:true },
  { id:8, name:"لحم بركر", description:"ساندويچ لحم بركر غني مع خضار وصوص خاص.", price:3500, category:"البركر", image:ASSETS.double, available:true },
  { id:30, name:"لفم لحم - دجاج", description:"سندويچ لحم أو دجاج مع الخضار وصوص فود بركر.", price:5000, category:"السندويچات", image:ASSETS.chicken, available:true },
  { id:9, name:"ريزو كبير", description:"وجبة ريزو كبيرة مع صوص فود بركر وبطاطا.", price:5000, category:"الوجبات", image:ASSETS.crispy, available:true },
  { id:10, name:"ريزو وسط", description:"وجبة ريزو وسط بطعم غني ومناسب.", price:4000, category:"الوجبات", image:ASSETS.crispy, available:true },
  { id:11, name:"ريزو لحم", description:"ريزو مع قطع لحم وصوص خاص.", price:6000, category:"الوجبات", image:ASSETS.double, available:true },
  { id:12, name:"وجبة تشكن", description:"وجبة دجاج مقرمش مع البطاطا والصوص.", price:6000, category:"الوجبات", image:ASSETS.chicken, available:true },
  { id:13, name:"زنجر عادي", description:"زنجر مقرمش مع خس وصوص داخل خبز طازج.", price:2000, category:"السندويچات", image:ASSETS.chicken, available:true },
  { id:14, name:"زنجر جبن", description:"زنجر مقرمش مع جبن ذائب وصوص خاص.", price:2500, category:"السندويچات", image:ASSETS.chicken, available:true },
  { id:15, name:"لفة كص", description:"لفة كص لحم مع خضار وصوص البيت.", price:2000, category:"السندويچات", image:ASSETS.double, available:true },
  { id:16, name:"فاهيتا لحم", description:"فاهيتا لحم متبلة مع خضار وصوص فود بركر.", price:2500, category:"السندويچات", image:ASSETS.double, available:true },
  { id:17, name:"بطاطا صغير", description:"بطاطا مقلية ذهبية ومقرمشة.", price:1500, category:"الإضافات", image:ASSETS.crispy, available:true },
  { id:18, name:"بطاطا وسط", description:"بطاطا مقلية ذهبية بحجم وسط.", price:2000, category:"الإضافات", image:ASSETS.crispy, available:true },
  { id:19, name:"بطاطا كبير", description:"بطاطا مقلية ذهبية بحجم كبير.", price:3000, category:"الإضافات", image:ASSETS.crispy, available:true },
  { id:20, name:"تشريب كص", description:"تشريب كص بصوص غني وخلطة البيت.", price:5000, category:"الوجبات", image:ASSETS.double, available:true },
  { id:21, name:"بيتزا صغير", description:"بيتزا صغيرة مع الجبن والصوص الخاص.", price:5000, category:"البيتزا", image:ASSETS.crispy, available:true },
  { id:22, name:"بيتزا وسط", description:"بيتزا وسط بحشوة فود بركر والجبن الذائب.", price:8000, category:"البيتزا", image:ASSETS.crispy, available:true },
  { id:23, name:"بيتزا كبير", description:"بيتزا كبيرة للمشاركة مع صوص خاص.", price:10000, category:"البيتزا", image:ASSETS.crispy, available:true },
  { id:24, name:"مقبلات صغير", description:"تشكيلة مقبلات خفيفة مع صوصات البيت.", price:1500, category:"المقبلات", image:ASSETS.crispy, available:true },
  { id:25, name:"مقبلات وسط", description:"تشكيلة مقبلات بحجم وسط للمشاركة.", price:2000, category:"المقبلات", image:ASSETS.crispy, available:true },
  { id:26, name:"مقبلات كبير", description:"تشكيلة مقبلات كبيرة مع صوصات جديدة.", price:3000, category:"المقبلات", image:ASSETS.crispy, available:true },
  { id:27, name:"فكر صغير", description:"وجبة خفيفة بحجم صغير مع صوص فود بركر.", price:1000, category:"الوجبات", image:ASSETS.chicken, available:true },
  { id:28, name:"فكر كبير", description:"وجبة خفيفة بحجم كبير مع صوص فود بركر.", price:2000, category:"الوجبات", image:ASSETS.chicken, available:true },
  { id:29, name:"لحم بعجين", description:"لحم بعجين طازج مع خلطة البيت.", price:3000, category:"الوجبات", image:ASSETS.double, available:true },
];
const fmt = (n:number) => `${n.toLocaleString("en-US")} د.ع`;

function CraftBand({ label="Food Burger" }: {label?:string}) { return <div className="craft-band" aria-hidden="true"><i/><span>{label}</span><i/><b>◆</b><i/><span>وجبات مميزة</span><i/></div>; }

function DishCard({ dish, quantity, onAdd, onChange }: {dish:Dish; quantity:number; onAdd:()=>void; onChange:(n:number)=>void}) {
  return <article className={`dish-card ${!dish.available ? "is-sold" : ""}`}>
    <div className="dish-photo"><img src={dish.image} alt={dish.name}/>{!dish.available && <div className="sold-stamp">نافذ</div>}<span className="dish-category">{dish.category}</span></div>
    <div className="dish-copy"><div className="dish-title-row"><h3>{dish.name}</h3><span className="price"><b>د.ع</b> {dish.price.toLocaleString("en-US")}</span></div><p>{dish.description}</p>
      {dish.available ? quantity === 0 ? <Button onClick={onAdd} className="order-button"><ShoppingBag size={16}/> طلب</Button> : <div className="quantity-control"><button aria-label="تقليل الكمية" onClick={()=>onChange(quantity-1)}><Minus size={16}/></button><strong>{quantity}</strong><button aria-label="زيادة الكمية" onClick={()=>onChange(quantity+1)}><Plus size={16}/></button><span>{fmt(dish.price*quantity)}</span></div> : <div className="sold-note">غير متوفر حاليًا</div>}
    </div>
  </article>;
}

function LocationPicker({ value, onChange }: {value: {lat:number; lng:number} | null; onChange:(location:{lat:number; lng:number} | null)=>void}) {
  const mapRef = useRef<google.maps.Map | null>(null); const markerRef = useRef<any>(null);
  const placeMarker = (map: google.maps.Map, position: {lat:number; lng:number}) => { if (!window.google?.maps?.marker) return; if (!markerRef.current) markerRef.current = new window.google.maps.marker.AdvancedMarkerElement({ map, position, title: "موقع التوصيل" }); else markerRef.current.position = position; map.panTo(position); };
  const handleMapReady = (map: google.maps.Map) => { mapRef.current = map; if (value) placeMarker(map, value); map.addListener("click", (event: google.maps.MapMouseEvent) => { if (!event.latLng) return; const next = { lat: event.latLng.lat(), lng: event.latLng.lng() }; placeMarker(map, next); onChange(next); }); };
  const useMyLocation = () => { if (!navigator.geolocation) { toast.error("المتصفح لا يدعم تحديد الموقع"); return; } navigator.geolocation.getCurrentPosition((position) => { const next = { lat: position.coords.latitude, lng: position.coords.longitude }; onChange(next); if (mapRef.current) { placeMarker(mapRef.current, next); mapRef.current.setZoom(16); } }, () => toast.error("تعذر الوصول إلى موقعك، اختر المكان بالنقر على الخريطة"), { enableHighAccuracy: true, timeout: 10000 }); };
  return <div className="location-picker"><div className="location-head"><div><strong>موقع التوصيل</strong><small>{value ? `تم التحديد: ${value.lat.toFixed(5)}, ${value.lng.toFixed(5)}` : "حدد مكانك على الخريطة ليسهل وصول الطلب"}</small></div><Button type="button" variant="outline" className="locate-button" onClick={useMyLocation}><MapPin size={15}/> تحديد موقعي</Button></div><MapView className="order-map" initialCenter={{lat:33.3152,lng:44.3661}} initialZoom={12} onMapReady={handleMapReady}/>{value && <button type="button" className="clear-location" onClick={()=>{onChange(null); if(markerRef.current) markerRef.current.map=null;}}>مسح الموقع</button>}</div>;
}

function Checkout({ items, total, restaurantPhone, onClose }: {items:{dish:Dish; quantity:number}[]; total:number; restaurantPhone:string; onClose:()=>void}) {
  const [form, setForm] = useState({name:"",phone:"",address:"",notes:""}); const [location,setLocation] = useState<{lat:number;lng:number} | null>(null);
  const submit = () => { if(!form.name || !form.phone || !form.address){ toast.error("يرجى إكمال الاسم ورقم الهاتف والعنوان"); return; } if(!location){ toast.error("يرجى تحديد موقع التوصيل على الخريطة"); return; } const lines = items.map(({dish,quantity})=>`• ${dish.name} × ${quantity} = ${fmt(dish.price*quantity)}`).join("\n"); const mapLink = `https://www.google.com/maps?q=${location.lat},${location.lng}`; const text = `طلب جديد من ${form.name}\nرقم الهاتف: ${form.phone}\nالعنوان: ${form.address}\nموقع التوصيل: ${mapLink}\nالإحداثيات: ${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}\n\n${lines}\n\nالمجموع: ${fmt(total)}${form.notes?`\nملاحظات: ${form.notes}`:""}`; window.open(`https://wa.me/${restaurantPhone.replace(/\D/g,"")}?text=${encodeURIComponent(text)}`, "_blank"); };
  return <div className="modal-backdrop"><div className="checkout-modal"><button className="modal-close" onClick={onClose}><X/></button><div className="modal-kicker">الخطوة الأخيرة</div><h2>أرسل طلبك عبر واتساب</h2><p className="muted">سيتواصل معك فريقنا لتأكيد الطلب والتوصيل.</p><div className="checkout-summary">{items.map(({dish,quantity})=><div key={dish.id}><span>{dish.name} × {quantity}</span><b>{fmt(dish.price*quantity)}</b></div>)}<div className="summary-total"><span>الإجمالي</span><b>{fmt(total)}</b></div></div><LocationPicker value={location} onChange={setLocation}/><div className="form-grid"><Input placeholder="الاسم الكامل" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/><Input placeholder="رقم الهاتف" inputMode="tel" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/><Input className="full" placeholder="العنوان بالتفصيل" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/><Textarea className="full" placeholder="ملاحظات إضافية (اختياري)" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></div><Button onClick={submit} className="whatsapp-button">إرسال الطلب عبر واتساب <ArrowLeft size={18}/></Button></div></div>;
}

function AdminPanel({ dishes, setDishes, onClose }: {dishes:Dish[]; setDishes:(d:Dish[])=>void; onClose:()=>void}) {
 const [logged, setLogged]=useState(false); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [editing,setEditing]=useState<Dish|null>(null); const [imagePreview,setImagePreview]=useState(""); const pickImage = (file?: File) => { if(!file) return; const reader = new FileReader(); reader.onload = () => { const data = String(reader.result); setImagePreview(data); if(editing) setEditing({...editing,image:data}); }; reader.readAsDataURL(file); };
 if(!logged) return <div className="modal-backdrop"><div className="admin-login"><button className="modal-close" onClick={onClose}><X/></button><img src={ASSETS.logo} className="login-mark" alt="شعار فود بركر"/><div className="modal-kicker">مساحة خاصة</div><h2>دخول الإدارة</h2><p className="muted">أدر المنيو والتوفر من مكان واحد.</p><Input placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)}/><Input type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)}/><Button className="order-button full-width" onClick={()=>{setLogged(true);toast.success("تم فتح لوحة الإدارة");}}>دخول آمن <KeyRound size={16}/></Button><small>واجهة تجريبية جاهزة للربط مع Firebase Authentication.</small></div></div>;
 const toggle=(id:number)=>setDishes(dishes.map(d=>d.id===id?{...d,available:!d.available}:d)); const remove=(id:number)=>setDishes(dishes.filter(d=>d.id!==id));
 return <div className="modal-backdrop"><div className="admin-modal"><div className="admin-head"><div><div className="modal-kicker">لوحة التحكم</div><h2>إدارة المنيو</h2></div><button className="modal-close static" onClick={onClose}><X/></button></div><div className="admin-toolbar"><span>{dishes.length} أصناف في المنيو</span><Button className="order-button" onClick={()=>{const n={id:Date.now(),name:"وجبة جديدة",description:"أضف وصف الوجبة من هنا.",price:8000,category:"الأطباق الرئيسية",image:"",available:true};setDishes([...dishes,n]);setEditing(n);setImagePreview("")}}><Plus size={16}/> إضافة وجبة</Button></div><div className="admin-list">{dishes.map(d=><div className="admin-row" key={d.id}><img src={d.image} alt=""/><div className="admin-info"><strong>{d.name}</strong><span>{fmt(d.price)} · {d.category}</span></div><button className={`availability ${d.available?"on":"off"}`} onClick={()=>toggle(d.id)}>{d.available?"متوفر":"نافذ"}</button><button className="icon-button" onClick={()=>setEditing(d)}><Pencil size={16}/></button><button className="icon-button danger" onClick={()=>remove(d.id)}><Trash2 size={16}/></button></div>)}</div>{editing&&<div className="edit-box"><div className="edit-title"><strong>تعديل الصنف</strong><button onClick={()=>setEditing(null)}><X size={16}/></button></div><label className="image-picker"><span className="image-preview">{(imagePreview || editing.image) ? <img src={imagePreview || editing.image} alt="معاينة صورة الوجبة"/> : <ImagePlus size={24}/>}</span><span><strong>صورة الوجبة</strong><small>اختر صورة من الاستوديو أو معرض الهاتف</small></span><input type="file" accept="image/*" onChange={e=>pickImage(e.target.files?.[0])}/><span className="upload-action"><Upload size={15}/> اختيار صورة</span></label><Input value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})}/><Input type="number" value={editing.price} onChange={e=>setEditing({...editing,price:Number(e.target.value)})}/><Textarea value={editing.description} onChange={e=>setEditing({...editing,description:e.target.value})}/><Button className="order-button full-width" onClick={()=>{setDishes(dishes.map(d=>d.id===editing.id?editing:d));setEditing(null);toast.success("تم حفظ التغييرات")}}>حفظ التغييرات</Button></div>}</div></div>;
}

export default function Home() {
 const [dishes,setDishes]=useState(seedDishes); const [category,setCategory]=useState("الكل"); const [cart,setCart]=useState<Record<number,number>>({}); const [checkout,setCheckout]=useState(false); const [admin,setAdmin]=useState(false);
 const categories=["الكل",...Array.from(new Set(dishes.map(d=>d.category)))]; const visible=category==="الكل"?dishes:dishes.filter(d=>d.category===category); const items=Object.entries(cart).map(([id,quantity])=>({dish:dishes.find(d=>d.id===Number(id))!,quantity})).filter(x=>x.dish); const total=items.reduce((s,x)=>s+x.dish.price*x.quantity,0); const count=items.reduce((s,x)=>s+x.quantity,0); const setQty=(id:number,n:number)=>setCart({...cart,[id]:Math.max(0,n)});
 return <div dir="rtl" className="app-shell"><header className="topbar"><div className="brand"><div className="brand-seal"><img src={ASSETS.logo} alt="شعار فود بركر"/></div><span>فود بركر<small>وجبات مميزة مع صلصات جديدة</small></span></div><Button variant="outline" className="admin-link" onClick={()=>setAdmin(true)}><KeyRound size={15}/> دخول الإدارة</Button></header><main><section className="hero"><div className="hero-copy"><div className="eyebrow"><span/> بركر عراقي، بطعم يعلق بالبال</div><h1>مزاجك بركر،<br/><em>وطلبك علينا.</em></h1><p>وجبات مميزة مع صلصات جديدة، تنطبخ طازة وتوصل لبابك. اختَر من منيو فود بركر بسهولة.</p><a href="#menu" className="hero-cta">تصفّح المنيو <ArrowLeft size={18}/></a></div><div className="hero-image"><img src={ASSETS.hero} alt="برغر فود بركر"/><div className="hero-note"><ChefHat size={18}/><span>طازج يوميًا<small>من فود بركر إلى بيتك</small></span></div></div></section><CraftBand label="Food Burger"/><section id="menu" className="menu-section"><div className="section-head"><div><div className="modal-kicker">منيو فود بركر</div><h2>اختَر البركر اللي يعجبك</h2></div><span className="section-count">{dishes.filter(d=>d.available).length} أصناف متوفرة</span></div><div className="category-bar">{categories.map(c=><button key={c} className={category===c?"active":""} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="dish-grid">{visible.map((dish,i)=><DishCard key={dish.id} dish={dish} quantity={cart[dish.id]||0} onAdd={()=>setQty(dish.id,1)} onChange={n=>setQty(dish.id,n)}/>)}</div></section><CraftBand label="بركر، صوص، مزاج"/></main><footer><span>© 2026 فود بركر</span><span>للتوصيل: 07833752202 · Instagram: @birkar_fud</span></footer>{count>0&&<div className="cart-bar"><div className="cart-count"><span>{count}</span><div><strong>طلبك جاهز تقريبًا</strong><small>{items.length} أصناف في السلة</small></div></div><div className="cart-total"><small>المجموع</small><strong>{fmt(total)}</strong></div><Button onClick={()=>setCheckout(true)} className="checkout-button">إكمال الطلب <ArrowLeft size={17}/></Button></div>}{checkout&&<Checkout items={items} total={total} restaurantPhone="9647833752202" onClose={()=>setCheckout(false)}/>} {admin&&<AdminPanel dishes={dishes} setDishes={setDishes} onClose={()=>setAdmin(false)}/>}</div>;
}
